import os
import pandas as pd
from google.cloud import bigquery
from google.cloud.bigquery.job import QueryJobConfig
import datetime

# Configuration - use your existing BILLING_PROJECT_ID

MIMIC_ICU_DATASET = "mimiciv_3_1_icu"  # MIMIC-IV ICU dataset
MIMIC_HOSP_DATASET = "mimiciv_3_1_hosp"  # MIMIC-IV hospital dataset

# Initialize BigQuery client
bq_client = bigquery.Client(project=BILLING_PROJECT_ID)

def get_icu_mortality_data():
    """
    Retrieves ICU mortality data for patients.
    
    Returns:
        DataFrame with patient_id (subject_id) and icu_mortality flag
    """
    mortality_query = f"""
    SELECT 
        i.subject_id as patient_id,
        MAX(CASE 
            WHEN ad.deathtime IS NOT NULL AND ad.deathtime BETWEEN i.intime AND i.outtime THEN 1
            ELSE 0
        END) AS icu_mortality
    FROM 
        `{PHYSIONET_PROJECT}.{MIMIC_ICU_DATASET}.icustays` i
    LEFT JOIN
        `{PHYSIONET_PROJECT}.{MIMIC_HOSP_DATASET}.admissions` ad
        ON i.hadm_id = ad.hadm_id
    GROUP BY 
        i.subject_id
    """
    
    # Execute query
    job_config = QueryJobConfig()
    job_config.use_legacy_sql = False
    
    # Run the query
    query_job = bq_client.query(mortality_query, job_config=job_config)
    
    # Process the results manually without db-dtypes
    result_list = []
    for row in query_job:
        row_dict = {}
        for key, value in row.items():
            row_dict[key] = value
        result_list.append(row_dict)
    
    # Create pandas DataFrame from the list of dicts
    mortality_df = pd.DataFrame(result_list)
    
    return mortality_df

def get_expanded_metrics_first_24hrs():
    """
    Retrieves vital signs and lab data for each patient at 30-minute intervals 
    for the first 24 hours of ICU stay, including expanded metrics.
    
    Returns:
        DataFrame with patient_id and metrics at 30-min intervals
    """
    # SQL query to extract various metrics at 30-minute intervals
    # for the first 24 hours of each patient's first ICU stay
    query = f"""
    WITH first_icu_stays AS (
        -- Get the first ICU stay for each patient
        SELECT 
            subject_id,
            stay_id,
            intime,
            outtime
        FROM 
            `{PHYSIONET_PROJECT}.{MIMIC_ICU_DATASET}.icustays`
        QUALIFY ROW_NUMBER() OVER (PARTITION BY subject_id ORDER BY intime) = 1
    ),
    
    -- Generate time buckets at 30-minute intervals for first 24 hours
    time_buckets AS (
        SELECT 
            stay_id,
            TIMESTAMP_ADD(intime, INTERVAL n * 30 MINUTE) AS bucket_time
        FROM 
            first_icu_stays
        CROSS JOIN 
            UNNEST(GENERATE_ARRAY(0, 47)) AS n  -- 0 to 47 = 48 buckets of 30 min = 24 hours
        WHERE 
            TIMESTAMP_ADD(intime, INTERVAL n * 30 MINUTE) <= 
            LEAST(TIMESTAMP_ADD(intime, INTERVAL 24 HOUR), outtime)
    ),
    
    -- Get vital signs and ventilator data from chartevents
    vital_signs AS (
        SELECT 
            ce.stay_id,
            ce.charttime,
            CASE 
                -- Vital signs
                WHEN ce.itemid = 220045 THEN 'heart_rate'
                WHEN ce.itemid = 220179 THEN 'non_invasive_sbp'
                WHEN ce.itemid = 220180 THEN 'non_invasive_dbp'
                WHEN ce.itemid = 220181 THEN 'non_invasive_mbp'
                WHEN ce.itemid = 220210 THEN 'respiratory_rate'
                WHEN ce.itemid = 223761 THEN 'temperature_celsius'
                WHEN ce.itemid = 220277 THEN 'spo2'
                
                -- Oxygen and ventilator metrics
                WHEN ce.itemid = 223835 THEN 'fio2'
                WHEN ce.itemid = 220224 THEN 'fio2'
                WHEN ce.itemid = 220339 THEN 'vent_mode'  -- For ventilator use 
                WHEN ce.itemid = 224688 THEN 'vent_status' -- Mechanical ventilation status
                WHEN ce.itemid = 229314 THEN 'vent_status_num' -- Mechanical ventilation status as 1/0
                
                -- Other
                WHEN ce.itemid = 226559 THEN 'sao2' -- Arterial O2 saturation
                WHEN ce.itemid = 220227 THEN 'urine_output' -- Urine output
            END AS vital_name,
            ce.valuenum AS vital_value,
            -- For ventilator status, we'll need the value as well to determine if patient is ventilated
            ce.value AS vital_value_text
        FROM 
            `{PHYSIONET_PROJECT}.{MIMIC_ICU_DATASET}.chartevents` ce
        JOIN 
            first_icu_stays fis ON ce.stay_id = fis.stay_id
        WHERE 
            ce.itemid IN (
                -- Vital signs
                220045,  -- Heart Rate
                220179,  -- Non Invasive Blood Pressure systolic
                220180,  -- Non Invasive Blood Pressure diastolic
                220181,  -- Non Invasive Blood Pressure mean
                220210,  -- Respiratory Rate
                223761,  -- Temperature Celsius
                220277,  -- O2 saturation pulseoxymetry (SpO2)
                
                -- Oxygen and ventilator metrics
                223835,  -- FiO2
                220224,  -- FiO2 (alternate)
                220339,  -- Ventilator mode
                224688,  -- Mechanical ventilation status
                229314,  -- Mechanical ventilation status (binary)
                
                -- Other
                226559,  -- SaO2 (arterial oxygen saturation)
                220227   -- Urine output
            )
            -- Either valuenum is not null or value is not null for text values like ventilator mode
            AND (ce.valuenum IS NOT NULL OR ce.value IS NOT NULL)
            AND ce.charttime BETWEEN fis.intime AND TIMESTAMP_ADD(fis.intime, INTERVAL 24 HOUR)
            AND ce.charttime <= fis.outtime
    ),
    
    -- Get lab data (WBC, lactate, platelets, etc.) from labevents
    lab_data AS (
        SELECT 
            ie.stay_id,
            le.charttime,
            CASE 
                WHEN le.itemid = 51300 THEN 'wbc'  -- WBC (White Blood Cell)
                WHEN le.itemid = 51301 THEN 'wbc'  -- WBC (alternate)
                WHEN le.itemid = 50822 THEN 'platelet_count'  -- Platelet Count
                WHEN le.itemid = 50821 THEN 'platelet_count'  -- Platelet Count (alternate)
                WHEN le.itemid = 51265 THEN 'lactate'  -- Lactate
                WHEN le.itemid = 50802 THEN 'BASE_excess' -- Base excess
                WHEN le.itemid = 50901 THEN 'pao2'  -- PaO2 (arterial)
                WHEN le.itemid = 51491 THEN 'pco2'  -- PCO2
            END AS lab_name,
            le.valuenum AS lab_value
        FROM 
            `{PHYSIONET_PROJECT}.{MIMIC_HOSP_DATASET}.labevents` le
        JOIN 
            first_icu_stays fis ON le.subject_id = fis.subject_id
        JOIN 
            `{PHYSIONET_PROJECT}.{MIMIC_ICU_DATASET}.icustays` ie ON le.subject_id = ie.subject_id
        WHERE 
            le.itemid IN (
                51300, 51301,  -- WBC
                50822, 50821,  -- Platelets
                51265,         -- Lactate
                50802,         -- Base excess
                50901,         -- PaO2
                51491          -- PCO2
            )
            AND le.valuenum IS NOT NULL
            -- Filter for lab values during ICU stay or slightly before (may have labs before ICU admission)
            AND le.charttime BETWEEN TIMESTAMP_SUB(fis.intime, INTERVAL 6 HOUR) AND TIMESTAMP_ADD(fis.intime, INTERVAL 24 HOUR)
            -- Also match the specific ICU stay
            AND le.charttime <= fis.outtime
            -- Only include stays that match the first ICU stay
            AND ie.stay_id = fis.stay_id
    ),
    
    -- Combine vital signs and lab data
    all_metrics AS (
        SELECT 
            stay_id,
            charttime,
            vital_name AS metric_name,
            vital_value AS metric_value,
            vital_value_text AS metric_text_value
        FROM 
            vital_signs
        
        UNION ALL
        
        SELECT 
            stay_id,
            charttime,
            lab_name AS metric_name,
            lab_value AS metric_value,
            NULL AS metric_text_value
        FROM 
            lab_data
    ),
    
    -- Assign metrics to the nearest 30-minute bucket
    bucketed_metrics AS (
        SELECT 
            am.stay_id,
            tb.bucket_time,
            am.metric_name,
            am.metric_value,
            am.metric_text_value,
            ROW_NUMBER() OVER (
                PARTITION BY am.stay_id, tb.bucket_time, am.metric_name 
                ORDER BY ABS(TIMESTAMP_DIFF(am.charttime, tb.bucket_time, SECOND))
            ) AS rn  -- Select the closest metric to each bucket time
        FROM 
            time_buckets tb
        JOIN 
            all_metrics am ON tb.stay_id = am.stay_id
        WHERE 
            ABS(TIMESTAMP_DIFF(am.charttime, tb.bucket_time, MINUTE)) <= 60  -- ±60 minute window for labs, which are less frequent
    ),
    
    -- Process ventilator status to create a binary indicator
    vent_status_processed AS (
        SELECT
            stay_id,
            bucket_time,
            1 AS is_ventilated  -- Assuming presence of a ventilator mode/status record means patient is ventilated
        FROM
            bucketed_metrics
        WHERE
            (metric_name = 'vent_mode' OR metric_name = 'vent_status') 
            AND rn = 1
        GROUP BY
            stay_id, bucket_time
    ),
    
    -- Select one value per metric per bucket (the closest in time)
    metrics_pivot_data AS (
        SELECT 
            bm.stay_id,
            bm.bucket_time,
            pat.subject_id AS patient_id,
            TIMESTAMP_DIFF(bm.bucket_time, fis.intime, MINUTE) AS minutes_from_admission,
            
            -- Vital signs
            MAX(CASE WHEN bm.metric_name = 'heart_rate' THEN bm.metric_value ELSE NULL END) AS heart_rate,
            MAX(CASE WHEN bm.metric_name = 'non_invasive_sbp' THEN bm.metric_value ELSE NULL END) AS sbp,
            MAX(CASE WHEN bm.metric_name = 'non_invasive_dbp' THEN bm.metric_value ELSE NULL END) AS dbp,
            MAX(CASE WHEN bm.metric_name = 'non_invasive_mbp' THEN bm.metric_value ELSE NULL END) AS mbp,
            MAX(CASE WHEN bm.metric_name = 'respiratory_rate' THEN bm.metric_value ELSE NULL END) AS resp_rate,
            MAX(CASE WHEN bm.metric_name = 'temperature_celsius' THEN bm.metric_value ELSE NULL END) AS temp_c,
            MAX(CASE WHEN bm.metric_name = 'spo2' THEN bm.metric_value ELSE NULL END) AS spo2,
            
            -- Oxygen and ventilator metrics
            MAX(CASE WHEN bm.metric_name = 'fio2' THEN bm.metric_value ELSE NULL END) AS fio2,
            MAX(CASE WHEN bm.metric_name = 'sao2' THEN bm.metric_value ELSE NULL END) AS sao2,
            MAX(CASE WHEN vsp.is_ventilated = 1 THEN 1 ELSE 0 END) AS is_ventilated,
            
            -- Lab data
            MAX(CASE WHEN bm.metric_name = 'wbc' THEN bm.metric_value ELSE NULL END) AS wbc,
            MAX(CASE WHEN bm.metric_name = 'platelet_count' THEN bm.metric_value ELSE NULL END) AS platelets,
            MAX(CASE WHEN bm.metric_name = 'lactate' THEN bm.metric_value ELSE NULL END) AS lactate,
            MAX(CASE WHEN bm.metric_name = 'pao2' THEN bm.metric_value ELSE NULL END) AS pao2,
            MAX(CASE WHEN bm.metric_name = 'pco2' THEN bm.metric_value ELSE NULL END) AS pco2,
            
            -- Other
            MAX(CASE WHEN bm.metric_name = 'urine_output' THEN bm.metric_value ELSE NULL END) AS urine_output,
            MAX(CASE WHEN bm.metric_name = 'BASE_excess' THEN bm.metric_value ELSE NULL END) AS base_excess
            
        FROM 
            bucketed_metrics bm
        JOIN 
            first_icu_stays fis ON bm.stay_id = fis.stay_id
        JOIN 
            `{PHYSIONET_PROJECT}.{MIMIC_ICU_DATASET}.icustays` pat ON bm.stay_id = pat.stay_id
        LEFT JOIN
            vent_status_processed vsp ON bm.stay_id = vsp.stay_id AND bm.bucket_time = vsp.bucket_time
        WHERE 
            bm.rn = 1  -- Select only the closest value
        GROUP BY 
            bm.stay_id, bm.bucket_time, pat.subject_id, fis.intime
    )
    
    -- Select final output with nice column names
    SELECT 
        patient_id,
        minutes_from_admission,
        
        -- Vital signs
        heart_rate,
        sbp,
        dbp,
        mbp,
        resp_rate,
        temp_c,
        spo2,
        
        -- Oxygen and ventilator metrics
        fio2,
        sao2,
        is_ventilated,
        
        -- Calculate P/F ratio when both values are available
        CASE 
            WHEN pao2 IS NOT NULL AND fio2 IS NOT NULL AND fio2 > 0 
            THEN pao2 / (fio2 / 100) 
            ELSE NULL 
        END AS pf_ratio,
        
        -- Lab data
        wbc,
        platelets,
        lactate,
        pao2,
        pco2,
        
        -- Other
        urine_output,
        base_excess
        
    FROM 
        metrics_pivot_data
    ORDER BY 
        patient_id, minutes_from_admission
    LIMIT 20000  -- Increased limit due to more patients/data
    """
    
    # Execute the query without using to_dataframe() which requires db-dtypes
    job_config = QueryJobConfig()
    job_config.use_legacy_sql = False
    
    # Run the query
    query_job = bq_client.query(query, job_config=job_config)
    
    # Define a function to convert BigQuery types to Python types
    def convert_bq_types(value):
        if isinstance(value, datetime.datetime):
            return value
        return value
    
    # Process the results manually without db-dtypes
    result_list = []
    for row in query_job:
        # Convert row to dict and handle any special types
        row_dict = {}
        for key, value in row.items():
            if isinstance(value, datetime.datetime):
                row_dict[key] = convert_bq_types(value)
            else:
                row_dict[key] = value
        result_list.append(row_dict)
    
    # Create pandas DataFrame from the list of dicts
    df = pd.DataFrame(result_list)
    
    # If the DataFrame is empty, return early
    if df.empty:
        return df
        
    # Reshape the data to have each timepoint as a column
    # This creates a wide format with patient_id as index and time intervals as columns
    metrics_to_pivot = [
        'heart_rate', 'sbp', 'dbp', 'mbp', 'resp_rate', 'temp_c', 'spo2',
        'fio2', 'sao2', 'is_ventilated', 'pf_ratio', 
        'wbc', 'platelets', 'lactate', 'pao2', 'pco2',
        'urine_output', 'base_excess'
    ]
    
    # Only include metrics that actually exist in the dataframe
    metrics_to_pivot = [m for m in metrics_to_pivot if m in df.columns]
    
    pivot_df = df.pivot_table(
        index='patient_id',
        columns='minutes_from_admission',
        values=metrics_to_pivot
    )
    
    # Flatten the column hierarchy and rename columns for clarity
    pivot_df.columns = [f'{col[0]}_{col[1]}min' for col in pivot_df.columns]
    
    # Reset index to make patient_id a regular column
    pivot_df = pivot_df.reset_index()
    
    # Get ICU mortality data in a separate query
    try:
        print("Fetching ICU mortality data...")
        mortality_df = get_icu_mortality_data()
        
        # Join mortality data with the pivoted metrics dataframe
        if not mortality_df.empty:
            pivot_df = pivot_df.merge(mortality_df, on='patient_id', how='left')
            
            # Fill NaN values in icu_mortality with 0 (assume patients with no data didn't die in ICU)
            pivot_df['icu_mortality'] = pivot_df['icu_mortality'].fillna(0).astype(int)
            print(f"Added mortality data for {mortality_df.shape[0]} patients")
    except Exception as e:
        print(f"Warning: Could not retrieve mortality data: {str(e)}")
    
    return pivot_df

# Main execution
if __name__ == "__main__":
    try:
        print("Fetching expanded metrics from MIMIC-IV...")
        df = get_expanded_metrics_first_24hrs()
        
        # Print basic info about the dataframe
        print(f"Retrieved data for {df.shape[0]} patients")
        print(f"Total columns: {df.shape[1]}")
        
        # Show mortality statistics if available
        if 'icu_mortality' in df.columns:
            mortality_count = df['icu_mortality'].sum()
            mortality_rate = (mortality_count / df.shape[0]) * 100
            print(f"ICU Mortality: {mortality_count} patients ({mortality_rate:.1f}%)")
        
        # Calculate the number of metrics
        if not df.empty:
            # Subtract patient_id and icu_mortality from column count
            metric_columns = df.shape[1]
            if 'icu_mortality' in df.columns:
                metric_columns -= 1
            metric_columns -= 1  # subtract patient_id
            
            metric_count = metric_columns / 48  # divide by 48 time points
            print(f"Number of metrics per patient: {metric_count:.1f}")
        
        # Display first few rows with limited columns for readability
        print("\nSample data (first few columns only):")
        sample_cols = ['patient_id']
        if 'icu_mortality' in df.columns:
            sample_cols.append('icu_mortality')
        additional_cols = [col for col in df.columns if '0min' in col or '30min' in col][:8]
        sample_cols.extend(additional_cols)
        print(df[sample_cols].head())
        
        # Optionally save to CSV
        df.to_csv("mimic_expanded_metrics_24hr.csv", index=False)
        
    except Exception as e:
        print(f"Error: {str(e)}")
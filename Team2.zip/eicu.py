import os
import pandas as pd
from google.cloud import bigquery

# Configuration - use your existing BILLING_PROJECT_ID
BILLING_PROJECT_ID = "level-strategy-383218"  # Your project ID
PHYSIONET_PROJECT = "physionet-data"
EICU_DATASET = "eicu_crd_derived"  # eICU dataset name (adjust if different)

# Initialize BigQuery client
bq_client = bigquery.Client(project=BILLING_PROJECT_ID)

def get_eicu_vital_signs_first_24hrs():
    """
    Retrieves vital signs data from eICU database for each patient at 30-minute intervals 
    for the first 24 hours of ICU stay.
    
    Returns:
        DataFrame with patientunitstayid and vital signs at 30-min intervals
    """
    # SQL query to extract vital signs at 30-minute intervals
    # for the first 24 hours of each patient's ICU stay
    query = f"""
    WITH time_buckets AS (
        -- Generate time buckets at 30-minute intervals for first 24 hours
        SELECT 
            patientunitstayid,
            n * 30 AS bucket_minutes  -- 30-minute intervals
        FROM 
            `{PHYSIONET_PROJECT}.{EICU_DATASET}.patient` p
        CROSS JOIN 
            UNNEST(GENERATE_ARRAY(0, 47)) AS n  -- 0 to 47 = 48 buckets of 30 min = 24 hours
    ),
    
    -- Get vital signs from vitalperiodic table
    vital_signs AS (
        SELECT 
            v.patientunitstayid,
            v.observationoffset,
            v.heartrate,
            v.systemicsystolic AS sbp,
            v.systemicdiastolic AS dbp,
            v.systemicmean AS mbp,
            v.respiration AS resp_rate,
            v.temperature,
            v.sao2 AS spo2
        FROM 
            `{PHYSIONET_PROJECT}.{EICU_DATASET}.vitalperiodic` v
        WHERE 
            v.observationoffset BETWEEN 0 AND 1440  -- 0 to 1440 minutes (24 hours)
    ),
    
    -- Assign vitals to the nearest 30-minute bucket
    bucketed_vitals AS (
        SELECT 
            tb.patientunitstayid,
            tb.bucket_minutes,
            vs.heartrate,
            vs.sbp,
            vs.dbp,
            vs.mbp,
            vs.resp_rate,
            vs.temperature,
            vs.spo2,
            ROW_NUMBER() OVER (
                PARTITION BY tb.patientunitstayid, tb.bucket_minutes
                ORDER BY ABS(vs.observationoffset - tb.bucket_minutes)
            ) AS rn  -- Select the closest vital sign to each bucket time
        FROM 
            time_buckets tb
        JOIN 
            vital_signs vs ON tb.patientunitstayid = vs.patientunitstayid
        WHERE 
            ABS(vs.observationoffset - tb.bucket_minutes) <= 15  -- ±15 minute window
    )
    
    -- Select final output from bucketed vitals
    SELECT 
        patientunitstayid AS patient_id,
        bucket_minutes AS minutes_from_admission,
        heartrate,
        sbp,
        dbp,
        mbp,
        resp_rate,
        temperature,
        spo2
    FROM 
        bucketed_vitals
    WHERE 
        rn = 1  -- Select only the closest value
    ORDER BY 
        patientunitstayid, bucket_minutes
    LIMIT 1000  -- Limit results (remove or adjust as needed)
    """
    
    # Execute the query
    df = bq_client.query(query).to_dataframe()
    
    # Reshape the data to have each timepoint as a column
    pivot_df = df.pivot_table(
        index='patient_id',
        columns='minutes_from_admission',
        values=['heartrate', 'sbp', 'dbp', 'mbp', 'resp_rate', 'temperature', 'spo2']
    )
    
    # Flatten the column hierarchy and rename columns for clarity
    pivot_df.columns = [f'{col[0]}_{col[1]}min' for col in pivot_df.columns]
    
    # Reset index to make patient_id a regular column
    pivot_df = pivot_df.reset_index()
    
    return pivot_df

# Main execution
if __name__ == "__main__":
    try:
        print("Fetching vital signs data from eICU...")
        vital_signs_df = get_eicu_vital_signs_first_24hrs()
        
        # Print basic info about the dataframe
        print(f"Retrieved data for {vital_signs_df.shape[0]} patients")
        print(f"Total columns: {vital_signs_df.shape[1]}")
        
        # Display first few rows
        print("\nSample data:")
        print(vital_signs_df.head())
        
        # Optionally save to CSV
        # vital_signs_df.to_csv("eicu_vital_signs_24hr.csv", index=False)
        
    except Exception as e:
        print(f"Error: {str(e)}")
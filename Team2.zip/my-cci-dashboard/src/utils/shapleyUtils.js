// src/utils/shapleyUtils.js (or keep within the component if preferred)

  // Map the original component keys to new clinical parameter names
  const componentNameMap = {
    'respiratory': 'PaO2/FiO2',
    'cardiovascular': 'Vasopressor/Inotrope Use',
    'coagulation': 'Hemoglobin', // Note: SHAP might use the actual metric driving the score
    'renal': 'Renal Replacement Therapy', // Note: SHAP might use the actual metric
    'demographics': 'Demographics (Age/Gender)',
    'vitals': 'Abnormal Vital Signs'
    // Add more mappings if your SHAP model outputs other features
  };

  // Get Shapley values formatted for waterfall chart
  const getShapleyWaterfallData = (timePoint) => {
    if (!timePoint || !timePoint.shapValues) return null;

    const shapValues = timePoint.shapValues;
    const baseValue = shapValues.base ?? 0; // Use nullish coalescing for safety
    const finalScore = timePoint.total ?? 0;

    // 1. Extract features and their SHAP values
    const features = Object.entries(shapValues)
      .filter(([key]) => key !== 'base')
      .map(([key, value]) => ({
        name: componentNameMap[key] || key.charAt(0).toUpperCase() + key.slice(1), // Use mapping or capitalize
        value: value,
      }));

    // 2. Sort features by absolute SHAP value, descending
    features.sort((a, b) => Math.abs(b.value) - Math.abs(a.value));

    // 3. Prepare data for the stacked bar waterfall
    const waterfallData = [];
    let cumulative = baseValue;

    // Add Base value entry
    waterfallData.push({
      name: 'E[CCI Score]', // Expected Value / Base
      base: 0, // Starts at 0
      value: baseValue, // Height is the base value itself
      cumulative: baseValue,
      isBase: true,
    });

    // Add sorted feature contributions
    features.forEach(feature => {
      const start = cumulative;
      const end = cumulative + feature.value;
      waterfallData.push({
        name: feature.name,
        base: Math.min(start, end), // The lower end of the bar for stacking
        value: feature.value, // The actual contribution (+ or -)
        cumulative: end, // End position after this feature
        isContribution: true,
      });
      cumulative = end;
    });

    // Add Final Score entry (optional, but good for comparison)
    // We can represent this implicitly by the final cumulative value
    // or add a specific marker if needed. Let's rely on the final cumulative value.

    // Sanity check: Ensure the final cumulative value matches the actual total score
    if (Math.abs(cumulative - finalScore) > 0.1) { // Allow for small floating point differences
        console.warn(`SHAP waterfall cumulative value (${cumulative.toFixed(2)}) differs slightly from actual score (${finalScore.toFixed(2)})`);
        // Optionally, force the last cumulative value to match the final score
        // if(waterfallData.length > 1) {
        //     waterfallData[waterfallData.length - 1].cumulative = finalScore;
        // }
    }


    return waterfallData;
  };
import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, Area, AreaChart, ComposedChart, Bar } from 'recharts';

// Convert minutes to hours:minutes format
const formatTime = (minutes) => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h${mins > 0 ? mins + 'm' : ''}`;
};

// Function to calculate Critical Care Index (CCI) based on metrics
const calculateCCI = (metrics) => {
  const scores = {};
  
  // Respiratory component
  if (metrics.pf_ratio != null) {
    const pfRatio = metrics.pf_ratio;
    const vent = metrics.is_ventilated || 0;
    
    if (pfRatio < 100 && vent === 1) scores.respiratory = 4;
    else if (pfRatio < 200 && vent === 1) scores.respiratory = 3;
    else if (pfRatio < 300) scores.respiratory = 2;
    else if (pfRatio < 400) scores.respiratory = 1;
    else scores.respiratory = 0;
  } else if (metrics.spo2 != null && metrics.fio2 != null && metrics.fio2 > 0) {
    const sfRatio = (metrics.spo2 / metrics.fio2) * 100;
    if (sfRatio < 89) scores.respiratory = 4;
    else if (sfRatio < 214) scores.respiratory = 3;
    else if (sfRatio < 357) scores.respiratory = 2;
    else if (sfRatio < 512) scores.respiratory = 1;
    else scores.respiratory = 0;
  } else {
    scores.respiratory = null;
  }
  
  // Cardiovascular component
  if (metrics.mbp != null) {
    scores.cardiovascular = metrics.mbp < 70 ? 1 : 0;
  } else {
    scores.cardiovascular = null;
  }
  
  // Renal component
  if (metrics.urine_output != null) {
    const urine = metrics.urine_output;
    if (urine < 200) scores.renal = 4;
    else if (urine < 500) scores.renal = 3;
    else scores.renal = 0;
  } else {
    scores.renal = null;
  }
  
  // Coagulation component
  if (metrics.platelets != null) {
    const platelets = metrics.platelets;
    if (platelets < 20) scores.coagulation = 4;
    else if (platelets < 50) scores.coagulation = 3;
    else if (platelets < 100) scores.coagulation = 2;
    else if (platelets < 150) scores.coagulation = 1;
    else scores.coagulation = 0;
  } else {
    scores.coagulation = null;
  }
  
  // Calculate total score
  const availableScores = Object.values(scores).filter(value => value !== null);
  if (availableScores.length > 0) {
    const avgScore = availableScores.reduce((sum, val) => sum + val, 0) / availableScores.length;
    // Scale to full range (0-24)
    scores.total = Math.min(avgScore * (24/4), 24);
  } else {
    scores.total = null;
  }
  
  return scores;
};

// Map the original component keys to new clinical parameter names
const componentNameMap = {
  'respiratory': 'PaO2/FiO2',
  'cardiovascular': 'Vasopressor/Inotrope Use',
  'coagulation': 'Hemoglobin',
  'renal': 'Renal Replacement Therapy'
};

// Mock function to load data - in real app would fetch from file or API
const loadPatientData = async () => {
  // This is mock data - would be replaced with actual data loading
  const mockPatients = [
    { id: 10045, mortality: 1, age: 72, gender: 'M', los: 4.2 },
    { id: 12589, mortality: 0, age: 56, gender: 'F', los: 2.8 },
    { id: 15729, mortality: 0, age: 43, gender: 'M', los: 3.1 },
    { id: 18934, mortality: 1, age: 67, gender: 'F', los: 5.6 },
    { id: 21478, mortality: 0, age: 39, gender: 'F', los: 1.9 }
  ];
  
  // Generate time series data
  const timePoints = Array.from({length: 49}, (_, i) => i * 30); // 0 to 1440 minutes in 30-min increments
  
  // Generate metrics for each patient
  const patientData = {};
  
  mockPatients.forEach(patient => {
    // Base trajectory depending on outcome
    const trajectory = patient.mortality 
      ? { start: 6, peak: 15, end: 20 } // Worse trajectory for mortality=1
      : { start: 4, peak: 8, end: 3 };  // Improving trajectory for mortality=0
    
    // Generate progression with some randomness
    const baseProgression = timePoints.map((time, i) => {
      const normalizedTime = time / 1440; // 0 to 1
      let score;
      
      if (normalizedTime < 0.3) {
        // First 30% of time: rise from start to peak
        score = trajectory.start + (trajectory.peak - trajectory.start) * (normalizedTime / 0.3);
      } else if (normalizedTime < 0.7) {
        // Middle: stay around peak
        score = trajectory.peak + (Math.random() * 4 - 2); // Small fluctuations
      } else {
        // Last 30%: move toward end value
        score = trajectory.peak + (trajectory.end - trajectory.peak) * ((normalizedTime - 0.7) / 0.3);
      }
      
      return Math.max(0, Math.min(24, score + (Math.random() * 2 - 1))); // Add noise, cap at 0-24
    });
    
    patientData[patient.id] = {
      demographics: patient,
      timePoints: timePoints.map((time, index) => {
        // Base vital sign patterns
        const baseHR = patient.mortality ? 100 : 85;
        const baseSBP = patient.mortality ? 110 : 125;
        const baseRR = patient.mortality ? 23 : 18;
        const baseSpo2 = patient.mortality ? 93 : 97;
        
        // Generate metrics with realistic patterns
        const metrics = {
          heart_rate: Math.max(50, Math.min(160, baseHR + (Math.sin(time/200) * 15) + (Math.random() * 10))),
          sbp: Math.max(80, Math.min(180, baseSBP + (Math.sin(time/250) * 12) + (Math.random() * 15))),
          dbp: Math.max(40, Math.min(110, (baseSBP * 0.65) + (Math.sin(time/250) * 8) + (Math.random() * 8))),
          mbp: Math.max(60, Math.min(120, (baseSBP * 0.75) + (Math.sin(time/250) * 10) + (Math.random() * 10))),
          resp_rate: Math.max(8, Math.min(35, baseRR + (Math.sin(time/300) * 4) + (Math.random() * 3))),
          spo2: Math.min(100, baseSpo2 + (Math.sin(time/350) * 2) + (Math.random() * 2)),
          fio2: 21 + (patient.mortality ? (30 + Math.random() * 49) : (Math.random() * 30)),
          is_ventilated: patient.mortality ? (time > 360 ? 1 : 0) : 0, // Intubated after 6h if mortality=1
          platelets: patient.mortality ? (150 - time/20) : (200 + Math.random() * 100),
          urine_output: patient.mortality ? 
            Math.max(100, 500 - time/4 + Math.random() * 200) : 
            Math.max(300, 600 + Math.random() * 300),
          time
        };
        
        // Set pf_ratio based on spo2 and fio2
        metrics.pf_ratio = metrics.fio2 > 21 ? 
          (500 - baseProgression[index] * 15) + (Math.random() * 50 - 25) : 
          null;
        
        // Calculate CCI score for this time point
        const cciScores = calculateCCI(metrics);
        
        // Force total to match our predetermined progression
        cciScores.total = baseProgression[index];
        
        // Generate mock SHAP values for each component (simulating feature importance)
        const baseValue = 5; // Base value (expected value) of the model
        
        // Calculate mock Shapley values that sum to the difference between total score and base value
        const totalDiff = cciScores.total - baseValue;
        
        // Create contributions that are proportional to the component scores but sum to totalDiff
        const componentKeys = ['respiratory', 'cardiovascular', 'coagulation', 'renal'];
        const componentValues = componentKeys.map(key => cciScores[key] || 0);
        const componentSum = componentValues.reduce((a, b) => a + b, 0) || 1; // Avoid division by zero
        
        const shapValues = {};
        componentKeys.forEach((key, i) => {
          if (componentSum === 0) {
            shapValues[key] = 0;
          } else {
            shapValues[key] = totalDiff * (componentValues[i] / componentSum);
          }
        });
        
        // Add other contributing factors
        shapValues.demographics = patient.age > 65 ? 1.2 : -0.5;
        shapValues.vitals = metrics.heart_rate > 100 ? 0.8 : -0.3;
        shapValues.base = baseValue;
        
        return {
          time,
          ...metrics,
          ...cciScores,
          shapValues
        };
      })
    };
  });
  
  return { patients: mockPatients, patientData };
};

// Color scale for CCI scores
const getCCIColor = (score) => {
  if (score === null) return '#ccc';
  if (score <= 6) return '#4caf50';    // Green
  if (score <= 12) return '#ff9800';   // Orange
  if (score <= 18) return '#f44336';   // Red
  return '#7b1fa2';                   // Purple for very high scores
};

const getRiskLabel = (score) => {
  if (score === null) return 'Unknown';
  if (score <= 6) return 'Low Risk';
  if (score <= 12) return 'Moderate Risk';
  if (score <= 18) return 'High Risk';
  return 'Severe Risk';
};

// Custom WaterfallChart component for Shapley values
const WaterfallChart = ({ data }) => {
  if (!data || data.length === 0) return null;
  
  // Calculate the positions for the bars
  let cumulativeValue = 0;
  const processedData = data.map((item, index) => {
    if (item.isBase) {
      cumulativeValue = item.value;
      return { ...item, start: 0, end: item.value };
    } else if (item.isFinal) {
      return { ...item, start: 0, end: item.value };
    } else {
      const start = cumulativeValue;
      cumulativeValue += item.value;
      return { ...item, start, end: cumulativeValue };
    }
  });
  
  // Find min and max for domain
  const allValues = processedData.flatMap(d => [d.start, d.end]);
  const minValue = Math.min(...allValues);
  const maxValue = Math.max(...allValues);
  const domain = [
    Math.floor(minValue - 1), 
    Math.ceil(maxValue + 1)
  ];
  
  return (
    <ResponsiveContainer width="100%" height={400}>
      <ComposedChart
        data={processedData}
        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
        <YAxis domain={domain} />
        <Tooltip 
          formatter={(value, name, props) => {
            if (props.payload.isBase) {
              return ['Base Value: ' + value.toFixed(1), ''];
            }
            if (props.payload.isFinal) {
              return ['Final Score: ' + value.toFixed(1), ''];
            }
            return [value > 0 ? '+' + value.toFixed(1) : value.toFixed(1), name];
          }}
        />
        <Legend />
        
        {processedData.map((entry, index) => {
          if (entry.isBase || entry.isFinal) {
            // Render a point for base and final values
            return (
              <Line
                key={`line-${index}`}
                type="monotone"
                dataKey="end"
                data={[entry]}
                stroke={entry.color}
                strokeWidth={2}
                dot={{ r: 6, fill: entry.color }}
                activeDot={{ r: 8 }}
                name={entry.name}
              />
            );
          } else {
            // Render a bar for contributions
            return (
              <React.Fragment key={`bar-${index}`}>
                <Bar
                  dataKey="value"
                  data={[entry]}
                  fill={entry.color}
                  name={entry.name}
                  stackId="stack"
                  barSize={30}
                />
                {/* Connector lines */}
                <Line
                  type="monotone"
                  dataKey="end"
                  data={[
                    processedData[index - 1],
                    { ...entry, end: entry.start }
                  ]}
                  stroke="#9e9e9e"
                  strokeWidth={1}
                  strokeDasharray="3 3"
                  dot={false}
                  activeDot={false}
                  name={`connector-${index}`}
                  legendType="none"
                />
              </React.Fragment>
            );
          }
        })}
      </ComposedChart>
    </ResponsiveContainer>
  );
};

// Custom tooltip component for the CCI chart that includes Shapley value information
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-3 border border-gray-200 shadow-lg rounded-md">
        <p className="font-medium text-gray-700">Time: {formatTime(data.time)}</p>
        <p className="text-[#2196f3] font-medium">CCI: {data.total.toFixed(1)}</p>
        
        <div className="mt-2 pt-2 border-t border-gray-200">
          <p className="text-xs text-gray-500 mb-1">Component Contributions:</p>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            {data.shapValues && Object.entries(data.shapValues).map(([key, value]) => {
              if (key !== 'base') {
                return (
                  <div key={key} className="flex justify-between">
                    <span className="text-xs text-gray-600">{key.charAt(0).toUpperCase() + key.slice(1)}:</span>
                    <span className={`text-xs font-medium ${value > 0 ? 'text-red-500' : 'text-green-500'}`}>
                      {value > 0 ? '+' : ''}{value.toFixed(1)}
                    </span>
                  </div>
                );
              }
              return null;
            })}
          </div>
          <p className="text-xs text-gray-500 mt-2">Click for detailed analysis</p>
        </div>
      </div>
    );
  }
  return null;
};

// Main dashboard component
const CriticalCareIndexDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [patients, setPatients] = useState([]);
  const [patientData, setPatientData] = useState({});
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [view, setView] = useState('overview'); // 'overview', 'detailed', 'components', 'shapley'
  const [selectedTimePoint, setSelectedTimePoint] = useState(null);
  
  // Load data on component mount
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const data = await loadPatientData();
        setPatients(data.patients);
        setPatientData(data.patientData);
        
        // Set first patient as selected by default
        if (data.patients.length > 0) {
          setSelectedPatient(data.patients[0].id);
        }
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // Update chart data when selected patient changes
  useEffect(() => {
    if (selectedPatient && patientData[selectedPatient]) {
      setChartData(patientData[selectedPatient].timePoints);
      // Reset selected time point when patient changes
      setSelectedTimePoint(null);
    }
  }, [selectedPatient, patientData]);
  
  // Use the global formatTime function defined at the top of the file
  
  // Get current CCI score for selected patient (last time point)
  const getCurrentCCIScore = () => {
    if (!selectedPatient || !chartData.length) return null;
    const lastTimePoint = chartData[chartData.length - 1];
    return lastTimePoint.total ? Math.round(lastTimePoint.total) : null;
  };
  
  // Get max CCI score for selected patient
  const getMaxCCIScore = () => {
    if (!selectedPatient || !chartData.length) return null;
    return Math.max(...chartData.map(point => point.total || 0));
  };
  
  // Format data for the component charts
  const getComponentData = () => {
    if (!selectedPatient || !chartData.length) return [];
    
    const components = ['respiratory', 'cardiovascular', 'coagulation', 'renal'];
    return components.map(component => {
      const values = chartData.filter(point => point[component] !== null);
      const avgScore = values.length > 0 
        ? values.reduce((sum, point) => sum + point[component], 0) / values.length 
        : null;
      
      return {
        name: componentNameMap[component] || component.charAt(0).toUpperCase() + component.slice(1),
        score: avgScore !== null ? avgScore.toFixed(1) : 'N/A',
        color: getCCIColor(avgScore)
      };
    });
  };
  
  // Get trend data for component view
  const getComponentTrendData = () => {
    if (!selectedPatient || !chartData.length) return [];
    
    // Get four timepoints - 0h, 8h, 16h, 24h
    const timeIndices = [0, 16, 32, 48].filter(i => i < chartData.length);
    const components = ['respiratory', 'cardiovascular', 'coagulation', 'renal'];
    
    return timeIndices.map(i => {
      const point = chartData[i];
      const result = { time: formatTime(point.time) };
      
      components.forEach(comp => {
        result[comp] = point[comp] || 0;
      });
      
      return result;
    });
  };
  
  // Get selected patient demographics
  const getSelectedPatientDemographics = () => {
    if (!selectedPatient || !patientData[selectedPatient]) return null;
    return patientData[selectedPatient].demographics;
  };
  
  // Get Shapley values for waterfall chart
  const getShapleyWaterfallData = () => {
    if (!selectedPatient || !chartData.length || selectedTimePoint === null) return null;
    
    const timePoint = chartData[selectedTimePoint];
    if (!timePoint || !timePoint.shapValues) return null;
    
    const shapValues = timePoint.shapValues;
    const baseValue = shapValues.base || 0;
    
    // Format data for waterfall chart
    const waterfallData = [];
    
    // Start with base value
    waterfallData.push({
      name: 'Base Value',
      value: baseValue,
      isBase: true,
      color: '#9e9e9e'
    });
    
    // Add component contributions
    const components = [
      { key: 'respiratory', name: 'PaO2/FiO2' },
      { key: 'cardiovascular', name: 'Vasopressor/Inotrope Use' },
      { key: 'coagulation', name: 'Hemoglobin' },
      { key: 'renal', name: 'Renal Replacement Therapy' },
      { key: 'demographics', name: 'Demographics' },
      { key: 'vitals', name: 'Vital Signs' }
    ];
    
    components.forEach(comp => {
      if (shapValues[comp.key] !== undefined) {
        waterfallData.push({
          name: comp.name,
          value: shapValues[comp.key],
          isPositive: shapValues[comp.key] > 0,
          color: shapValues[comp.key] > 0 ? '#f44336' : '#4caf50'
        });
      }
    });
    
    // Add final value
    waterfallData.push({
      name: 'Final Score',
      value: timePoint.total,
      isFinal: true,
      color: getCCIColor(timePoint.total)
    });
    
    return waterfallData;
  };
  
  // Handler for point click in the chart
  const handlePointClick = (data, index) => {
    setSelectedTimePoint(index);
    // If not already in Shapley view, switch to it
    if (view !== 'shapley') {
      setView('shapley');
    }
  };
  
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
        <div className="w-16 h-16 border-4 border-t-blue-500 border-gray-200 rounded-full animate-spin"></div>
        <p className="mt-4 text-lg font-medium text-gray-700">Loading patient data...</p>
      </div>
    );
  }
  
  const currentScore = getCurrentCCIScore();
  const maxScore = getMaxCCIScore();
  const componentData = getComponentData();
  const demographics = getSelectedPatientDemographics();
  const componentTrendData = getComponentTrendData();
  const shapleyData = getShapleyWaterfallData();
  
  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Critical Care Index</h1>
            <p className="text-gray-600">Patient condition monitoring dashboard</p>
          </div>
          
          {/* View selector */}
          <div className="flex space-x-2 bg-gray-200 rounded-lg p-1">
            <button 
              className={`px-4 py-2 rounded-md text-sm font-medium ${
                view === 'overview' ? 'bg-white shadow text-gray-800' : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setView('overview')}
            >
              Overview
            </button>
            <button 
              className={`px-4 py-2 rounded-md text-sm font-medium ${
                view === 'detailed' ? 'bg-white shadow text-gray-800' : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setView('detailed')}
            >
              Detailed View
            </button>
            <button 
              className={`px-4 py-2 rounded-md text-sm font-medium ${
                view === 'shapley' ? 'bg-white shadow text-gray-800' : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setView('shapley')}
            >
              Shapley Analysis
            </button>
          </div>
        </div>
        
        {/* Main content */}
        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
          <div className="col-span-12 md:col-span-3 lg:col-span-2">
            <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
              <div className="bg-blue-500 px-4 py-3">
                <h2 className="text-white font-medium">Patient Selection</h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {patients.map(patient => (
                  <button
                    key={patient.id}
                    onClick={() => setSelectedPatient(patient.id)}
                    className={`w-full px-4 py-3 text-left focus:outline-none transition duration-150 ease-in-out ${
                      selectedPatient === patient.id 
                        ? 'bg-blue-50 border-l-4 border-blue-500' 
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium text-gray-900">#{patient.id}</div>
                        <div className="text-sm text-gray-500">{patient.gender}, {patient.age} years</div>
                      </div>
                      <div className={`w-3 h-3 rounded-full ${patient.mortality ? 'bg-red-500' : 'bg-green-500'}`}></div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            
            {/* Patient details */}
            {demographics && (
              <div className="bg-white shadow rounded-lg overflow-hidden">
                <div className="bg-gray-100 px-4 py-3 border-b border-gray-200">
                  <h2 className="font-medium text-gray-700">Patient Details</h2>
                </div>
                
                <div className="px-4 py-3">
                  <dl className="grid grid-cols-1 gap-x-4 gap-y-2">
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">ID</dt>
                      <dd className="text-sm text-gray-900">{demographics.id}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Age</dt>
                      <dd className="text-sm text-gray-900">{demographics.age} years</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Gender</dt>
                      <dd className="text-sm text-gray-900">{demographics.gender}</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">LOS</dt>
                      <dd className="text-sm text-gray-900">{demographics.los} days</dd>
                    </div>
                    <div className="flex justify-between">
                      <dt className="text-sm font-medium text-gray-500">Status</dt>
                      <dd className={`text-sm ${demographics.mortality ? 'text-red-600 font-medium' : 'text-green-600 font-medium'}`}>
                        {demographics.mortality ? 'Deceased' : 'Survived'}
                      </dd>
                    </div>
                  </dl>
                </div>
              </div>
            )}
          </div>
          
          {/* Main content area */}
          <div className="col-span-12 md:col-span-9 lg:col-span-10">
            {selectedPatient && (
              <>
                {/* Charts based on current view */}
                <div className="bg-white shadow rounded-lg overflow-hidden">
                  {view === 'overview' && (
                    <div>
                      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
                        <h3 className="font-medium text-gray-700">CCI Progression (First 24 Hours)</h3>
                      </div>
                      
                      <div className="p-4">
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <AreaChart 
                              data={chartData} 
                              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                              onClick={(data, index) => handlePointClick(data, index)}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis 
                                dataKey="time" 
                                tickFormatter={formatTime}
                                ticks={[0, 360, 720, 1080, 1440]}
                              />
                              <YAxis domain={[0, 24]} />
                              <Tooltip 
                                content={<CustomTooltip />}
                              />
                              
                              {/* Reference areas for risk levels */}
                              <defs>
                                <linearGradient id="colorLow" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#4caf50" stopOpacity={0.1}/>
                                  <stop offset="95%" stopColor="#4caf50" stopOpacity={0}/>
                                </linearGradient>
                                <linearGradient id="colorMed" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#ff9800" stopOpacity={0.1}/>
                                  <stop offset="95%" stopColor="#ff9800" stopOpacity={0}/>
                                </linearGradient>
                                <linearGradient id="colorHigh" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#f44336" stopOpacity={0.1}/>
                                  <stop offset="95%" stopColor="#f44336" stopOpacity={0}/>
                                </linearGradient>
                                <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="5%" stopColor="#2196f3" stopOpacity={0.8}/>
                                  <stop offset="95%" stopColor="#2196f3" stopOpacity={0}/>
                                </linearGradient>
                              </defs>
                              
                              {/* Reference lines for risk thresholds */}
                              <ReferenceLine y={6} stroke="#4caf50" strokeDasharray="3 3" />
                              <ReferenceLine y={12} stroke="#ff9800" strokeDasharray="3 3" />
                              <ReferenceLine y={18} stroke="#f44336" strokeDasharray="3 3" />
                              
                              {/* Main CCI area */}
                              <Area 
                                type="monotone" 
                                dataKey="total" 
                                name="Critical Care Index"
                                stroke="#2196f3" 
                                fill="url(#colorUv)"
                                strokeWidth={3}
                                activeDot={{ r: 6 }}
                                fillOpacity={0.2}
                              />
                            </AreaChart>
                          </ResponsiveContainer>
                        </div>
                        
                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                          <div>Admission</div>
                          <div>6 hours</div>
                          <div>12 hours</div>
                          <div>18 hours</div>
                          <div>24 hours</div>
                        </div>
                        
                        <div className="flex justify-between mt-4">
                          <div className="flex items-center">
                            <span className="w-3 h-3 bg-green-500 rounded-full mr-1"></span>
                            <span className="text-xs text-gray-600">Low Risk (0-6)</span>
                          </div>
                          <div className="flex items-center">
                            <span className="w-3 h-3 bg-yellow-500 rounded-full mr-1"></span>
                            <span className="text-xs text-gray-600">Moderate Risk (7-12)</span>
                          </div>
                          <div className="flex items-center">
                            <span className="w-3 h-3 bg-red-500 rounded-full mr-1"></span>
                            <span className="text-xs text-gray-600">High Risk (13-18)</span>
                          </div>
                          <div className="flex items-center">
                            <span className="w-3 h-3 bg-purple-500 rounded-full mr-1"></span>
                            <span className="text-xs text-gray-600">Severe Risk (19-24)</span>
                          </div>
                        </div>
                        
                        <div className="mt-4 p-3 bg-gray-50 rounded-md border border-gray-200">
                          <p className="text-sm text-gray-700 mb-1 font-medium">Shapley Value Analysis</p>
                          <p className="text-xs text-gray-600">
                            Click on any point in the chart to see a detailed Shapley value analysis. 
                            Shapley values explain how each component contributes to the final CCI score 
                            by showing the marginal contribution of each feature.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {view === 'detailed' && (
                    <div>
                      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
                        <h3 className="font-medium text-gray-700">Detailed Vital Signs</h3>
                      </div>
                      <div className="p-4">
                        <p className="text-sm text-gray-600 mb-4">
                          This view shows detailed vital sign progression over the first 24 hours.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {/* Heart Rate Chart */}
                          <div className="bg-white shadow rounded-lg p-4 border border-gray-100">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Net Fluid Balance</h4>
                            <div className="h-60">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart 
                                  data={chartData} 
                                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis 
                                    dataKey="time" 
                                    tickFormatter={formatTime}
                                    ticks={[0, 360, 720, 1080, 1440]}
                                  />
                                  <YAxis domain={[40, 180]} />
                                  <Tooltip />
                                  <ReferenceLine y={60} stroke="#4caf50" strokeDasharray="3 3" />
                                  <ReferenceLine y={100} stroke="#ff9800" strokeDasharray="3 3" />
                                  <Line 
                                    type="monotone" 
                                    dataKey="heart_rate" 
                                    stroke="#e91e63" 
                                    dot={false}
                                    strokeWidth={2}
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                          
                          {/* Blood Pressure Chart */}
                          <div className="bg-white shadow rounded-lg p-4 border border-gray-100">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Vasopressor/Inotrope Dose</h4>
                            <div className="h-60">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart 
                                  data={chartData} 
                                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis 
                                    dataKey="time" 
                                    tickFormatter={formatTime}
                                    ticks={[0, 360, 720, 1080, 1440]}
                                  />
                                  <YAxis domain={[30, 200]} />
                                  <Tooltip />
                                  <ReferenceLine y={90} stroke="#4caf50" strokeDasharray="3 3" />
                                  <ReferenceLine y={140} stroke="#ff9800" strokeDasharray="3 3" />
                                  <Line 
                                    type="monotone" 
                                    dataKey="sbp" 
                                    name="Systolic BP"
                                    stroke="#f44336" 
                                    dot={false}
                                    strokeWidth={2}
                                  />
                                  <Line 
                                    type="monotone" 
                                    dataKey="dbp" 
                                    name="Diastolic BP"
                                    stroke="#2196f3" 
                                    dot={false}
                                    strokeWidth={2}
                                  />
                                  <Line 
                                    type="monotone" 
                                    dataKey="mbp" 
                                    name="Mean BP"
                                    stroke="#4caf50" 
                                    dot={false}
                                    strokeWidth={2}
                                    strokeDasharray="5 5"
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                          
                          {/* Respiratory Chart */}
                          <div className="bg-white shadow rounded-lg p-4 border border-gray-100">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Mechanical Ventilation Status</h4>
                            <div className="h-60">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart 
                                  data={chartData} 
                                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis 
                                    dataKey="time" 
                                    tickFormatter={formatTime}
                                    ticks={[0, 360, 720, 1080, 1440]}
                                  />
                                  <YAxis domain={[5, 40]} />
                                  <Tooltip />
                                  <ReferenceLine y={12} stroke="#4caf50" strokeDasharray="3 3" />
                                  <ReferenceLine y={20} stroke="#ff9800" strokeDasharray="3 3" />
                                  <Line 
                                    type="monotone" 
                                    dataKey="resp_rate" 
                                    stroke="#9c27b0" 
                                    dot={false}
                                    strokeWidth={2}
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                          
                          {/* Oxygenation Chart */}
                          <div className="bg-white shadow rounded-lg p-4 border border-gray-100">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Lactate/Creatinine</h4>
                            <div className="h-60">
                              <ResponsiveContainer width="100%" height="100%">
                                <LineChart 
                                  data={chartData} 
                                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                                >
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis 
                                    dataKey="time" 
                                    tickFormatter={formatTime}
                                    ticks={[0, 360, 720, 1080, 1440]}
                                  />
                                  <YAxis yAxisId="left" domain={[80, 100]} />
                                  <YAxis yAxisId="right" orientation="right" domain={[0, 600]} />
                                  <Tooltip />
                                  <ReferenceLine yAxisId="left" y={94} stroke="#ff9800" strokeDasharray="3 3" />
                                  <ReferenceLine yAxisId="right" y={300} stroke="#ff9800" strokeDasharray="3 3" />
                                  <Line 
                                    yAxisId="left"
                                    type="monotone" 
                                    dataKey="spo2" 
                                    name="SpO2 (%)"
                                    stroke="#00bcd4" 
                                    dot={false}
                                    strokeWidth={2}
                                  />
                                  <Line 
                                    yAxisId="right"
                                    type="monotone" 
                                    dataKey="pf_ratio" 
                                    name="P/F Ratio"
                                    stroke="#ff9800" 
                                    dot={false}
                                    strokeWidth={2}
                                    strokeDasharray="5 5"
                                  />
                                </LineChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {view === 'components' && (
                    <div>
                      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
                        <h3 className="font-medium text-gray-700">Clinical Parameters Analysis</h3>
                      </div>
                      <div className="p-4">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                          {componentData.map((component, index) => (
                            <div key={index} className="bg-white shadow rounded-lg p-4 border border-gray-100">
                              <h4 className="text-sm font-medium text-gray-700 mb-2">{component.name}</h4>
                              <div className="flex items-center">
                                <div 
                                  className="w-16 h-16 rounded-full flex items-center justify-center mr-3 text-white font-bold text-xl"
                                  style={{ backgroundColor: component.color }}
                                >
                                  {component.score}
                                </div>
                                <div>
                                  <p className="text-xs text-gray-500">Average Score</p>
                                  <p className="text-sm text-gray-700 mt-1">
                                    {component.name === 'Respiratory' && Number(component.score) >= 2 && 
                                      'Significant respiratory dysfunction'}
                                    {component.name === 'Respiratory' && Number(component.score) < 2 && 
                                      'Mild respiratory changes'}
                                    {component.name === 'Cardiovascular' && Number(component.score) >= 1 && 
                                      'Compromised circulation'}
                                    {component.name === 'Cardiovascular' && Number(component.score) < 1 && 
                                      'Stable circulation'}
                                    {component.name === 'Coagulation' && Number(component.score) >= 2 && 
                                      'Significant coagulopathy'}
                                    {component.name === 'Coagulation' && Number(component.score) < 2 && 
                                      'Adequate coagulation'}
                                    {component.name === 'Renal' && Number(component.score) >= 2 && 
                                      'Renal dysfunction present'}
                                    {component.name === 'Renal' && Number(component.score) < 2 && 
                                      'Adequate renal function'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        {/* Component Trends */}
                        <div className="bg-white shadow rounded-lg p-4 border border-gray-100 mb-4">
                          <h4 className="text-sm font-medium text-gray-700 mb-3">Component Trends</h4>
                          <div className="h-60">
                            <ResponsiveContainer width="100%" height="100%">
                              <LineChart data={componentTrendData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="time" />
                                <YAxis domain={[0, 4]} />
                                <Tooltip />
                                <Legend />
                                <Line 
                                  type="monotone" 
                                  dataKey="respiratory" 
                                  name="Respiratory"
                                  stroke="#f44336" 
                                  strokeWidth={2} 
                                />
                                <Line 
                                  type="monotone" 
                                  dataKey="cardiovascular" 
                                  name="Cardiovascular"
                                  stroke="#2196f3" 
                                  strokeWidth={2} 
                                />
                                <Line 
                                  type="monotone" 
                                  dataKey="coagulation" 
                                  name="Coagulation"
                                  stroke="#ff9800" 
                                  strokeWidth={2} 
                                />
                                <Line 
                                  type="monotone" 
                                  dataKey="renal" 
                                  name="Renal"
                                  stroke="#4caf50" 
                                  strokeWidth={2} 
                                />
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                        
                        {/* Clinical Interpretation */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Clinical Interpretation</h4>
                            <p className="text-sm text-gray-600">
                              {demographics?.mortality 
                                ? "This patient shows progressive multi-organ dysfunction with worsening scores over time. Particularly concerning is the respiratory component, suggesting ARDS development. Early intervention for ventilatory support and hemodynamic management is critical."
                                : "This patient shows initial organ dysfunction that improves over time, suggesting positive response to treatment. The transient elevation in scores does not persist, indicating successful clinical management and intervention."
                              }
                            </p>
                          </div>
                          <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Intervention Suggestions</h4>
                            <ul className="text-sm text-gray-600 space-y-1">
                              {componentData.find(c => c.name === 'PaO2/FiO2' && Number(c.score) >= 2) && 
                                <li>• Consider lung-protective ventilation strategy</li>}
                              {componentData.find(c => c.name === 'Vasopressor/Inotrope Use' && Number(c.score) >= 1) && 
                                <li>• Optimize fluid management and vasopressor support</li>}
                              {componentData.find(c => c.name === 'Hemoglobin' && Number(c.score) >= 2) && 
                                <li>• Monitor for bleeding risk and consider blood transfusion</li>}
                              {componentData.find(c => c.name === 'Renal Replacement Therapy' && Number(c.score) >= 2) && 
                                <li>• Ensure adequate renal perfusion and avoid nephrotoxins</li>}
                              <li>• Re-evaluate within 6 hours to assess trajectory</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {view === 'shapley' && (
                    <div>
                      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
                        <h3 className="font-medium text-gray-700">
                          Shapley Value Analysis {selectedTimePoint !== null ? `(${formatTime(chartData[selectedTimePoint]?.time || 0)})` : ''}
                        </h3>
                      </div>
                      
                      <div className="p-4">
                        {selectedTimePoint === null ? (
                          <div className="flex flex-col items-center justify-center h-60 text-gray-500">
                            <svg className="w-16 h-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                            <p>Select a point from the Overview chart to view Shapley values</p>
                          </div>
                        ) : (
                          <div>
                            <div className="mb-4">
                              <p className="text-sm text-gray-700 mb-2">
                                The waterfall chart below shows how each component contributes to the final CCI score
                                at time point {formatTime(chartData[selectedTimePoint]?.time || 0)}.
                              </p>
                              <p className="text-sm text-gray-700">
                                Positive values (red) increase the score, while negative values (green) decrease it.
                                The base value represents the expected average score.
                              </p>
                            </div>
                            
                            {shapleyData && <WaterfallChart data={shapleyData} />}
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                              <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                                <h4 className="text-sm font-medium text-gray-700 mb-2">Component Importance</h4>
                                <div className="space-y-2">
                                  {chartData[selectedTimePoint]?.shapValues && 
                                    Object.entries(chartData[selectedTimePoint].shapValues)
                                      .filter(([key]) => key !== 'base')
                                      .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
                                      .map(([key, value]) => (
                                        <div key={key} className="flex items-center">
                                          <div className="w-32 text-sm text-gray-700">
                                            {key.charAt(0).toUpperCase() + key.slice(1)}:
                                          </div>
                                          <div className="flex-1 bg-gray-200 rounded-full h-4">
                                            <div 
                                              className={`h-4 rounded-full ${value > 0 ? 'bg-red-500' : 'bg-green-500'}`}
                                              style={{ width: `${Math.min(100, Math.abs(value) * 15)}%` }}
                                            ></div>
                                          </div>
                                          <div className={`w-12 text-right text-sm font-medium ${value > 0 ? 'text-red-500' : 'text-green-500'}`}>
                                            {value > 0 ? '+' : ''}{value.toFixed(1)}
                                          </div>
                                        </div>
                                      ))
                                  }
                                </div>
                              </div>
                              
                              <div className="bg-gray-50 p-3 rounded-md border border-gray-200">
                                <h4 className="text-sm font-medium text-gray-700 mb-2">Clinical Interpretation</h4>
                                <p className="text-sm text-gray-600">
                                  Shapley values help explain which factors are driving the CCI score at this time point.
                                  {chartData[selectedTimePoint]?.shapValues?.respiratory > 1 && 
                                    " PaO2/FiO2 ratio appears to be a significant contributor."}
                                  {chartData[selectedTimePoint]?.shapValues?.cardiovascular > 1 && 
                                    " Vasopressor/Inotrope use is notably affecting the patient's condition."}
                                  {chartData[selectedTimePoint]?.shapValues?.renal > 1 && 
                                    " Renal Replacement Therapy parameters show concerning values."}
                                  {chartData[selectedTimePoint]?.shapValues?.coagulation > 1 && 
                                    " Hemoglobin levels are significantly abnormal."}
                                </p>
                                <p className="text-sm text-gray-600 mt-2">
                                  Consider these key contributors when planning interventions to improve patient outcomes.
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CriticalCareIndexDashboard;
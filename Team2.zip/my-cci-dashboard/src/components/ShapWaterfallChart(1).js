// src/components/ShapWaterfallChart.js
import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine, LabelList, Cell
} from 'recharts';

// Define colors for positive and negative contributions
const POSITIVE_COLOR = '#f44336'; // Red for positive contribution (increases score)
const NEGATIVE_COLOR = '#4caf50'; // Green for negative contribution (decreases score)
const BASE_COLOR = '#9e9e9e';     // Grey for base value

const formatValueLabel = (value) => {
    if (value === 0) return "0.0";
    return (value > 0 ? '+' : '') + value.toFixed(1);
};

const CustomTooltipContent = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload; // The data point for this bar

    let valueToShow = 0;
    let valueLabel = '';

    if (data.isBase) {
        valueToShow = data.value;
        valueLabel = 'Base Value';
    } else if (data.isContribution) {
        valueToShow = data.value;
        valueLabel = 'Contribution';
    } else {
        // Could add handling for a potential 'Final' bar if explicitly added
        valueToShow = data.cumulative;
        valueLabel = 'Cumulative';
    }


    return (
      <div className="bg-white p-2 border border-gray-300 shadow-lg rounded text-sm">
        <p className="font-bold text-gray-700">{`${data.name}`}</p>
        {data.isContribution && (
            <p style={{ color: data.value > 0 ? POSITIVE_COLOR : NEGATIVE_COLOR }}>
                {`Contribution: ${formatValueLabel(data.value)}`}
            </p>
        )}
        <p className="text-gray-600">{`Cumulative Score: ${data.cumulative.toFixed(1)}`}</p>
        {data.isBase && (
             <p className="text-gray-600">{`Base (Expected) Score: ${data.value.toFixed(1)}`}</p>
        )}
      </div>
    );
  }

  return null;
};


const ShapWaterfallChart = ({ data }) => {
  if (!data || data.length === 0) return <p>No Shapley data available for this point.</p>;

  // Determine Y-axis domain dynamically
  const allValues = data.flatMap(d => [d.base, d.cumulative, d.isBase ? d.value : d.base + d.value]);
  const minY = Math.min(...allValues);
  const maxY = Math.max(...allValues);
  const buffer = Math.max(1, (maxY - minY) * 0.1); // Add 10% buffer or at least 1 unit
  const yDomain = [Math.floor(minY - buffer), Math.ceil(maxY + buffer)];

  // Find base and final values for reference lines
  const baseValue = data.find(d => d.isBase)?.value ?? 0;
  const finalValue = data[data.length - 1]?.cumulative ?? 0;


  return (
    <ResponsiveContainer width="100%" height={450}>
      <BarChart
        data={data}
        margin={{ top: 20, right: 30, left: 20, bottom: 100 }} // Increased bottom margin for labels
        barGap={0} // Bars touch to simulate connectors visually
      >
        <CartesianGrid strokeDasharray="3 3" vertical={false}/>
        <XAxis
            dataKey="name"
            angle={-60} // Angle labels to prevent overlap
            textAnchor="end"
            interval={0} // Show all labels
            tick={{ fontSize: 10 }} // Smaller font size
            height={80} // Allocate space for angled labels
        />
        <YAxis domain={yDomain} width={50} />
        <Tooltip content={<CustomTooltipContent />} cursor={{ fill: 'rgba(206, 206, 206, 0.2)' }}/>
        <Legend wrapperStyle={{ top: -10, left: 25 }} payload={[
             { value: 'Increases Score', type: 'square', id: 'ID01', color: POSITIVE_COLOR },
             { value: 'Decreases Score', type: 'square', id: 'ID02', color: NEGATIVE_COLOR },
        ]}/>

        {/* Reference Lines */}
        <ReferenceLine y={baseValue} stroke={BASE_COLOR} strokeDasharray="2 2">
            <Label value={`Base = ${baseValue.toFixed(1)}`} position="insideTopRight" fill={BASE_COLOR} fontSize={10}/>
        </ReferenceLine>
         <ReferenceLine y={finalValue} stroke="#333" strokeDasharray="2 2">
             <Label value={`Final = ${finalValue.toFixed(1)}`} position="insideTopLeft" fill="#333" fontSize={10}/>
         </ReferenceLine>

        {/* Invisible bar for positioning */}
        <Bar dataKey="base" stackId="a" fill="transparent" />

        {/* Visible contribution bar */}
        <Bar dataKey="value" stackId="a">
            {/* Label for the contribution value */}
            <LabelList
                dataKey="value"
                position="top" // Adjust position based on sign? Maybe "center" is better
                formatter={formatValueLabel}
                style={{ fontSize: '10px' }}
                content={(props) => {
                    const { x, y, width, value } = props;
                    // Don't render label for the transparent base part or the base bar itself
                    if (value === 0 || data[props.index]?.isBase) return null;
                    // Adjust label position based on bar direction
                    const yPos = value > 0 ? y - 5 : y + 15; // Position above positive, below negative
                    const fill = value > 0 ? POSITIVE_COLOR : NEGATIVE_COLOR;
                    return <text x={x + width / 2} y={yPos} fill={fill} textAnchor="middle" fontSize={10}>{formatValueLabel(value)}</text>;
                }}
            />
            {/* Color cells based on contribution sign or if it's the base */}
             {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={
                    entry.isBase ? BASE_COLOR : (entry.value >= 0 ? POSITIVE_COLOR : NEGATIVE_COLOR)
                }/>
             ))}
        </Bar>

      </BarChart>
    </ResponsiveContainer>
  );
};

export default ShapWaterfallChart;